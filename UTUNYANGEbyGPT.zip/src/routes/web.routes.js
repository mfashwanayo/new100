const router=require("express").Router();
const auth=require("../modules/auth/routes"),admin=require("../modules/admin/routes");
const admin4=require("../modules/admin/stage4.routes"),teacher=require("../modules/teacher/routes");
const teacher4=require("../modules/teacher/stage4.routes"),student=require("../modules/student/routes"),parent=require("../modules/parent/routes");
const {requireAuth,requireRole}=require("../middleware/auth.middleware");
[
 ["/","public/home","Welcome","home"],["/about","public/about","About UTUNYANGE","about"],
 ["/admissions","public/admissions","Admissions","admissions"],["/academics","public/academics","Academics","academics"],
 ["/news","public/news","News & Events","news"],["/contact","public/contact","Contact Us","contact"]
].forEach(([url,view,title,active])=>router.get(url,(req,res)=>res.render(view,{title,active})));
router.get("/login",(req,res)=>req.session.user?res.redirect("/dashboard"):res.render("auth/login",{title:"Sign in",error:null,loggedOut:req.query.loggedOut==="1"}));
router.use("/auth",auth);
router.get("/dashboard",requireAuth,(req,res)=>{const role=req.session.user.role;const target={super_admin:"admin",admin:"admin",teacher:"teacher",student:"student",parent:"parent",staff:"staff"}[role];res.redirect(target?`/dashboard/${target}`:"/login");});
router.use("/dashboard/admin",requireAuth,requireRole("admin","super_admin"),admin);
router.use("/dashboard/admin",requireAuth,requireRole("admin","super_admin"),admin4);
router.use("/dashboard/teacher",requireAuth,requireRole("teacher"),teacher);
router.use("/dashboard/teacher",requireAuth,requireRole("teacher"),teacher4);
router.use("/dashboard/student",requireAuth,requireRole("student"),student);
router.use("/dashboard/parent",requireAuth,requireRole("parent"),parent);
router.get("/dashboard/staff",requireAuth,requireRole("staff"),(req,res)=>res.render("staff/dashboard",{title:"Staff dashboard",user:req.session.user}));
module.exports=router;
